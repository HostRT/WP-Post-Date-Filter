<?php
/**
 * Plugin Name: Post Date Filter for SmartMag
 * Description: Adds a date filter to display posts from a specific date
 * Version: 1.0
 * Author: Shubham Sahu
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

class Post_Date_Filter {
    
    public function __construct() {
        // Add shortcode for the date filter form and results
        add_shortcode('post_date_filter', array($this, 'date_filter_shortcode'));
        
        // Add admin menu
        add_action('admin_menu', array($this, 'add_admin_menu'));
        
        // Register settings
        add_action('admin_init', array($this, 'register_settings'));
        
        // Enqueue scripts and styles
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
    }
    
    /**
     * Enqueue necessary scripts and styles
     */
    public function enqueue_scripts() {
        // jQuery UI datepicker for better date selection
        wp_enqueue_script('jquery-ui-datepicker');
        wp_enqueue_style('jquery-ui', 'https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css');
        
        // Custom CSS
        wp_enqueue_style('post-date-filter-css', plugin_dir_url(__FILE__) . 'css/post-date-filter.css');
        
        // Custom JS
        wp_enqueue_script('post-date-filter-js', plugin_dir_url(__FILE__) . 'js/post-date-filter.js', array('jquery', 'jquery-ui-datepicker'), '1.0', true);
    }
    
    /**
     * Add admin menu page
     */
    public function add_admin_menu() {
        add_menu_page(
            'Post Date Filter', 
            'Post Date Filter', 
            'manage_options', 
            'post-date-filter', 
            array($this, 'admin_page'),
            'dashicons-calendar-alt',
            30
        );
    }
    
    /**
     * Register settings
     */
    public function register_settings() {
        register_setting('post_date_filter_settings', 'pdf_post_types');
        register_setting('post_date_filter_settings', 'pdf_posts_per_page');
    }
    
    /**
     * Admin page content
     */
    public function admin_page() {
        ?>
        <div class="wrap">
            <h1>Post Date Filter Settings</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('post_date_filter_settings');
                do_settings_sections('post_date_filter_settings');
                
                $post_types = get_post_types(array('public' => true), 'objects');
                $selected_post_types = get_option('pdf_post_types', array('post'));
                $posts_per_page = get_option('pdf_posts_per_page', 10);
                ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">Post Types to Include</th>
                        <td>
                            <?php foreach ($post_types as $post_type) : ?>
                                <label>
                                    <input type="checkbox" name="pdf_post_types[]" value="<?php echo esc_attr($post_type->name); ?>" 
                                        <?php checked(in_array($post_type->name, $selected_post_types)); ?>>
                                    <?php echo esc_html($post_type->labels->singular_name); ?>
                                </label><br>
                            <?php endforeach; ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Posts Per Page</th>
                        <td>
                            <input type="number" name="pdf_posts_per_page" value="<?php echo esc_attr($posts_per_page); ?>" min="1" max="100">
                        </td>
                    </tr>
                </table>
                
                <?php submit_button(); ?>
            </form>
            
            <div class="shortcode-info">
                <h2>How to Use</h2>
                <p>Use the shortcode <code>[post_date_filter]</code> on any page to display the date filter form.</p>
            </div>
        </div>
        <?php
    }
    
    /**
     * Shortcode callback function
     */
    public function date_filter_shortcode($atts) {
        // Extract shortcode attributes
        $atts = shortcode_atts(array(
            'title' => 'Filter Posts by Date',
            'btn_text' => 'Filter Posts',
        ), $atts);
        
        // Start output buffering
        ob_start();
        
        // Get selected post types from settings
        $post_types = get_option('pdf_post_types', array('post'));
        $posts_per_page = get_option('pdf_posts_per_page', 10);
        
        // Get the selected date from URL parameter
        $selected_date = isset($_GET['filter_date']) ? sanitize_text_field($_GET['filter_date']) : '';
        
        // Display the form
        ?>
        <div class="post-date-filter-container">
            <h2><?php echo esc_html($atts['title']); ?></h2>
            
            <form method="get" class="post-date-filter-form">
                <?php
                // Preserve existing query parameters
                foreach ($_GET as $key => $value) {
                    if ($key !== 'filter_date') {
                        echo '<input type="hidden" name="' . esc_attr($key) . '" value="' . esc_attr($value) . '">';
                    }
                }
                ?>
                
                <div class="date-selector">
                    <label for="filter_date">Select Date:</label>
                    <input type="text" id="filter_date" name="filter_date" class="datepicker" value="<?php echo esc_attr($selected_date); ?>" placeholder="YYYY-MM-DD" autocomplete="off">
                </div>
                
                <button type="submit" class="filter-button"><?php echo esc_html($atts['btn_text']); ?></button>
            </form>
            
            <?php
            // If a date is selected, display posts from that date
            if (!empty($selected_date)) {
                // Parse the date
                $date = date_create_from_format('Y-m-d', $selected_date);
                
                if ($date) {
                    // Format for display
                    $display_date = $date->format('F j, Y');
                    
                    // Query parameters
                    $args = array(
                        'post_type' => $post_types,
                        'posts_per_page' => $posts_per_page,
                        'date_query' => array(
                            array(
                                'year' => $date->format('Y'),
                                'month' => $date->format('m'),
                                'day' => $date->format('d'),
                            ),
                        ),
                    );
                    
                    // Run the query
                    $query = new WP_Query($args);
                    
                    // Display results
                    ?>
                    <div class="post-date-filter-results">
                        <h3>Posts from <?php echo esc_html($display_date); ?></h3>
                        
                        <?php if ($query->have_posts()) : ?>
                            <div class="post-list">
                                <?php while ($query->have_posts()) : $query->the_post(); ?>
                                    <article class="post-item">
                                        <div class="post-item-inner">
                                            <?php if (has_post_thumbnail()) : ?>
                                                <div class="post-thumbnail">
                                                    <a href="<?php the_permalink(); ?>">
                                                        <?php the_post_thumbnail('medium'); ?>
                                                    </a>
                                                </div>
                                            <?php endif; ?>
                                            
                                            <div class="post-content">
                                                <h3 class="post-title">
                                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                                </h3>
                                                
                                                <div class="post-meta">
                                                    <span class="post-category"><?php echo esc_html(get_the_category()[0]->name); ?></span>
                                                    <span class="post-date"><?php echo get_the_date('F j, Y'); ?></span>
                                                </div>
                                                
                                                <div class="post-excerpt">
                                                    <?php echo wp_trim_words(get_the_excerpt(), 25); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </article>
                                <?php endwhile; ?>
                            </div>
                            
                            <?php
                            // Pagination
                            echo '<div class="pagination">';
                            echo paginate_links(array(
                                'total' => $query->max_num_pages,
                                'current' => max(1, get_query_var('paged')),
                                'prev_text' => '&laquo; Previous',
                                'next_text' => 'Next &raquo;',
                            ));
                            echo '</div>';
                            ?>
                            
                        <?php else : ?>
                            <p class="no-posts">No posts found for this date.</p>
                        <?php endif; ?>
                        
                        <?php wp_reset_postdata(); ?>
                    </div>
                    <?php
                } else {
                    echo '<p class="error">Invalid date format. Please use YYYY-MM-DD format.</p>';
                }
            }
            ?>
        </div>
        <?php
        
        // Get the buffer contents and end buffering
        return ob_get_clean();
    }
}

// Initialize the plugin
$post_date_filter = new Post_Date_Filter();

// Create CSS directory and file on plugin activation
register_activation_hook(__FILE__, 'pdf_create_files');

function pdf_create_files() {
    // Create CSS directory
    $css_dir = plugin_dir_path(__FILE__) . 'css';
    if (!file_exists($css_dir)) {
        mkdir($css_dir, 0755, true);
    }
    
    // Create CSS file
    $css_file = $css_dir . '/post-date-filter.css';
    if (!file_exists($css_file)) {
        $css_content = '/* Post Date Filter Styles */
.post-date-filter-container {
    margin: 30px 0;
    padding: 20px;
    background: #fff;
    border-radius: 0;
    box-shadow: none;
}

.post-date-filter-form {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    margin-bottom: 20px;
    border-bottom: 1px solid #eee;
    padding-bottom: 20px;
}

.date-selector {
    margin-right: 15px;
    margin-bottom: 10px;
}

.date-selector label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
}

.datepicker {
    padding: 8px 12px;
    border: 1px solid #ddd;
    border-radius: 4px;
    min-width: 200px;
}

.filter-button {
    padding: 8px 15px;
    background: #0073aa;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    margin-top: 22px;
}

.filter-button:hover {
    background: #005177;
}

.post-date-filter-results h3 {
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 1px solid #eee;
}

/* Post List Styles - Similar to Image 2 */
.post-list {
    margin: 0;
    padding: 0;
}

.post-item {
    margin-bottom: 30px;
    border-bottom: 1px solid #eee;
    padding-bottom: 30px;
}

.post-item-inner {
    display: flex;
    align-items: flex-start;
}

.post-thumbnail {
    flex: 0 0 240px;
    margin-right: 20px;
}

.post-thumbnail img {
    width: 100%;
    height: auto;
    display: block;
}

.post-content {
    flex: 1;
}

.post-title {
    margin-top: 0;
    margin-bottom: 10px;
    font-size: 18px;
    line-height: 1.4;
}

.post-title a {
    color: #333;
    text-decoration: none;
}

.post-title a:hover {
    color: #0073aa;
}

.post-meta {
    margin-bottom: 12px;
    font-size: 13px;
    color: #777;
}

.post-category {
    color: #cc0000;
    font-weight: bold;
    margin-right: 10px;
}

.post-date {
    color: #777;
}

.post-excerpt {
    font-size: 14px;
    line-height: 1.6;
    color: #555;
}

.pagination {
    margin-top: 20px;
    text-align: center;
}

.no-posts, .error {
    padding: 20px;
    background: #fff;
    border-left: 4px solid #dc3232;
}

/* Responsive adjustments */
@media (max-width: 768px) {
    .post-item-inner {
        flex-direction: column;
    }
    
    .post-thumbnail {
        flex: 0 0 auto;
        margin-right: 0;
        margin-bottom: 15px;
        width: 100%;
    }
}';
        file_put_contents($css_file, $css_content);
    }
    
    // Create JS directory
    $js_dir = plugin_dir_path(__FILE__) . 'js';
    if (!file_exists($js_dir)) {
        mkdir($js_dir, 0755, true);
    }
    
    // Create JS file
    $js_file = $js_dir . '/post-date-filter.js';
    if (!file_exists($js_file)) {
        $js_content = 'jQuery(document).ready(function($) {
    // Initialize datepicker
    $(".datepicker").datepicker({
        dateFormat: "yy-mm-dd",
        changeMonth: true,
        changeYear: true,
        yearRange: "2000:+1"
    });
});';
        file_put_contents($js_file, $js_content);
    }
}